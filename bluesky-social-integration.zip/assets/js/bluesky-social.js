(function(){
    console.log('BlueSky Social Integration - Admin JS is working');
})();